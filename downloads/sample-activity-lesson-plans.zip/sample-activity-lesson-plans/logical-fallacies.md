###### VDES 25892 Visual Design 2: Visual Rhetoric  /  Week05

## Identifying Logical Fallacies

###### Bridge In

Show students two examples (of logical fallacies) that argue opposing sides. First, show the one that most of the students in the room are unlikely to agree with, then show them the more 'popular' opinion. After they've discussed, reveal each one is a logical fallacy.

###### Objective/Outcome

Students will be able to identify logical fallacies so they  can identify when they are being used and avoid using them in their own work. 

###### Pre-assessment

Students will example slides and will be asked to identify and discuss the pros and cons of each argument. After each example has been shown, it will be revealed as containing a logical fallacy, and that fallacy will be named and explained. *Note: these examples should be kept up-to-date to maintain relevance to students.*

###### Participatory Learning

Once all examples have been viewed and discussed, students will be split into their project groups and be asked to write three potential poster headlines for their topic. Two should contain logical fallacies, and one should not.

###### Post-assessment

Students will share their three statements with the class. Their peers must listen carefully and identify which statements contain logical fallacies, and which one does not. They must also attempt to name the logical fallacy their peers have used.

###### Summary

A summation discussion of the use/consequences of logical fallacies should be had. This should tie back to how visuals (image and type) support the underlying message of words, and placed within the current design/socio-political landscape as it relates to the topics/stances of their current projects.



---

#### Assets + Room Requirements

- [ ] Slide Deck
- [ ] Paper
- [ ] Pens
- [ ] Projector
- [ ] Tables

---

###### References/Links

https://owl.english.purdue.edu/owl/resource/659/03/

https://www.youtube.com/playlist?list=PLtHP6qx8VF7dPql3ll1To4i6vEIPt0kV5

https://yourlogicalfallacyis.com/



