**Due to the academic work stoppage during the 2017 fall semester, course evaluations were not held. To supplement this portfolio, I asked some students for candid feedback on me as as instructor.** — Meredith Thompson



"I had the opportunity of having Meredith facilitate my very first course in the interaction design program. Following that first semester, I have actively tried to have at least one course with her as my instructor because of how much I learn and enjoy her classes. Meredith's professional experience and passion for design are always evident during her lectures and tutorial sessions. She makes great use of current trends to teach modern, functional design. Her enthusiasm has greatly assisted in my understanding of design theory and graphic design; interaction frameworks and UX design; and persuasive visual communication. As well, she always finds time to teach students to the full extent of the curriculum even with class stoppages due to holidays, weather-related cancellations, and the month-long strike in the Fall 2017 semester.

Meredith is not only a fantastic instructor, but teacher who has provided me and other students the skills necessary to succeed, not just in future courses in the interaction design program, but also in the field of design as professionals."

— Carlo Dormiendo, IXD student



"There are not enough words to describe the positive impact Meredith Thompson had on my learning at Sheridan College. I will not forget the first time I met Meredith– she was energetic, honest and engaging. I was drawn to her confident disposition. Throughout the semester, she proved herself to be an outstanding teacher and mentor. Meredith helped guide my thesis work, in and out of the classroom, having the ability to quickly determine and communicate what I needed to move forward. During our critiques, Meredith consistently offered an intelligent and empathetic perspective. It was clear in her critiques and lessons that her knowledge extends far beyond design. Meredith has helped me grow as both a designer and person. "

— Kim Wright, IXD graduate



"Meredith Thompson is one of the best and most important professors that I have had the pleasure of learning from. She prioritizes student work and individual growth, giving each student a chance to grow as a designer. She teaches in a very kind and open-minded manor that allows us all to be at ease, and is always up to date with both design and global trends.

As a student of her's I have not only grown from critiques and suggestions for my designs but have also grown as an Interaction Designer and the way in which I understand users and myself. Her constant feedback and critique is always appreciated and done in a manor that has helped me grow leaps and bounds since my first year. She has contributed to my learning in a positive way and is without a doubt one of the best professors in the program."

— JJ Bastida, IXD student



