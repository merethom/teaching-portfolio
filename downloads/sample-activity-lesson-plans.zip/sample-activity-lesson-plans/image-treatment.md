

## The importance of image treatment

##### Bridge In

Show two different examples that use imagery as a rhetorical/narrative aid: one successful and one that misses the mark.

#####Objective/Outcome

For students to think critically about narrative implication of image cropping, framing, position and styling when using imagery rhetorically.

#####Pre-assessment

Show students the same image cropped two different ways, with two different headlines. After the first one, discuss the narrative implications of the image, and then show the second.

#####Participatory Learning

After a brief lesson that gives both theory and practical suggestions (included below) , students will be given an image and a headline. It is up to them to crop/modify that image to add the maximum amount of rhetorical power to support the headline. Students will share their results with the class statements with the class. Unbeknownst to them, some of the students have the same image with a different headline. They will discuss and evaluate/critique their peers' work with instructor guidance. 

#####Summary

A summation of key takeaways will be outlined and discussed in relation to the activity.

---

#### Assets + Room Requirements

- [ ] Slide Deck
- [ ] Images + Headlines

